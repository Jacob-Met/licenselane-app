The Tidal Archive
Between Water and Sky / LicenseLane Studio

Between Water and Sky, plate I. A library above the turning tide, reached by a single causeway. Editable vector artwork and a 3,600 × 2,400 print file.

Files: editable SVG, 3600 x 2400 PNG (3:2). The PNG is 12 x 8 inches at 300 pixels per inch; the SVG scales without loss. Both depict the same complete plate, including its margin and title.

Original code-authored illustration by astra-c29f for the LicenseLane demonstration, 2026. No external source artwork. These repository demonstration assets use the repository MIT license; Sandbox approval and payment do not grant additional rights or imply outside creator adoption.
